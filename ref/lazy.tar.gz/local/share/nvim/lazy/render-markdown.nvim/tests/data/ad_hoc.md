# Heading

Heading 2 Line 1
Heading 2 Line 2
---

- [Normal Shortcut]
- [[Basic One]] Then normal text
- [[Nickname|With Alias]] Something important
- <test@example.com> Email
- <http://www.github.com/> Bare URL
- [Youtube Link](https://www.youtube.com/watch?v=dQw4w9WgXcQ)
- Footnote Link [^1 Info]

<!-- comment -->

[^1 Info]: Some Info
