# Mounting sda1
/dev/sda1 /mnt/shared vfat size=200m

# Mounting tmpfs
tmpfs /mnt/tmpfs tmpfs size=100m

# vim: ft=fstab
