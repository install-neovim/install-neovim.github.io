# Table with Inline

| Heading 1 | `Heading 2`            |
| --------- | ---------------------: |
| `Item 行` | [link](https://行.com) |
| &lt;1&gt; | ==Itém 2==             |

# Table no Inline

| Heading 1 | Heading 2 |
| --------- | --------- |
| Item 1    | Item 2    |
