# Note

> [!NOTE]
>
> A regular note
>
> With a second paragraph

# Tip

> [!TIP]
>
> ```lua
> print('Standard tip')
> ```

# Important

> [!IMPORTANT]
> Exceptional info

# Warning

> [!WARNING] Custom Title
> Dastardly surprise

# Caution

> [!caution]
> Cautionary tale

# Bug

> [!bUg]
> Custom bug
