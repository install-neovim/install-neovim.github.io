# LaTeX

$\sqrt{3x-1}+(1+x)^2$

$$
f(x,y) = x + \sqrt{y}
f(x,y) = \sqrt{y} + \frac{x^2}{4y}
$$
