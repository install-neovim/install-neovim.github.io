# TODOs

- Potentially change LuaRocks icon dependency to [mini.icons](https://luarocks.org/modules/neorocks/mini.icons)
